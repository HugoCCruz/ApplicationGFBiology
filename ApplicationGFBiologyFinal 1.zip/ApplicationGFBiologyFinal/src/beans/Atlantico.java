
package beans;


public class Atlantico {
    
    private String nome;
    private String especie;
    private double peso;
    private double comprimento;

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public void setComprimento(double comprimento) {
        this.comprimento = comprimento;
    }

    public String getNome() {
        return nome;
    }

    public String getEspecie() {
        return especie;
    }

    public double getPeso() {
        return peso;
    }

    public double getComprimento() {
        return comprimento;
    }

    
    
}
