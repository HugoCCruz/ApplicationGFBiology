package dao;

import beans.Login;
import Conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LoginDAO {

    private Conexao conexao;
    private Connection conn;

    public LoginDAO() {
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }

   
    public boolean checkLogin(String email, String senha) {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        boolean check = false;  

        try {
           
            stmt = conn.prepareStatement("SELECT * FROM login WHERE email=? AND senha=?");
            stmt.setString(1, email);
            stmt.setString(2, senha);

            
            rs = stmt.executeQuery();

            
            if (rs.next()) {
                check = true;
            }
        } catch (SQLException ex) {
           
            System.out.println("Erro ao obter login: " + ex.getMessage());
            Logger.getLogger(LoginDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
           
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            } catch (SQLException e) {
                Logger.getLogger(LoginDAO.class.getName()).log(Level.SEVERE, null, e);
            }
        }

        return check;  
    }
}


