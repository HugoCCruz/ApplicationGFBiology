
package dao;

import beans.Cadastro;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import Conexao.Conexao;
import java.sql.Connection;

public class CadastroDAO {
    
    List<String> listaLogin = new ArrayList<>();
    
    public void inicializarLista() {
        listaLogin = new ArrayList<>(); 
        listaLogin.add("Elemento 1");
        listaLogin.add("Elemento 2");
    }
    
    public void processarLista() {
        if (listaLogin != null) {
            for (String item : listaLogin) {
                System.out.println(item); 
            }
        } else {
            System.out.println("A lista est� vazia ou n�o foi inicializada.");
        }
    }

    private Conexao conexao;
    private Connection conn;

    public CadastroDAO() {
    this.conexao = new Conexao();
    this.conn = this.conexao.getConexao();
    }
    
    public void inserir(Cadastro cadastro) {
    String sql = "INSERT INTO login (email, senha) VALUES (?, ?)";
    try {
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setString(1, cadastro.getEmail());
        stmt.setString(2, cadastro.getSenha());
        stmt.execute();
    } catch (Exception e) {
        System.out.println("Erro ao inserir login: " + e.getMessage());
        }
    }
    
    
    }


