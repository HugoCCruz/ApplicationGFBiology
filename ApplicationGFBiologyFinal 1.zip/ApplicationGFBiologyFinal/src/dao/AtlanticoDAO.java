package dao;

import beans.Atlantico;
import Conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class AtlanticoDAO {

    
    
    List<String> listaAtlantico = new ArrayList<>();

    
    public void inicializarLista() {
        listaAtlantico = new ArrayList<>(); 
        listaAtlantico.add("Elemento 1");
        listaAtlantico.add("Elemento 2");
    }

    
    public void processarLista() {
        if (listaAtlantico != null) {
            for (String item : listaAtlantico) {
                System.out.println(item); 
            }
        } else {
            System.out.println("A lista est� vazia ou n�o foi inicializada.");
        }
    }

    private Conexao conexao;
    private Connection conn;

    
    public AtlanticoDAO() {
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }

    
    public void inserir(Atlantico atlantico) {
        String sql = "INSERT INTO atlantico (nome, especie, peso, comprimento) VALUES (?, ?, ?, ?)";
        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, atlantico.getNome());
            stmt.setString(2, atlantico.getEspecie());
            stmt.setDouble(3, atlantico.getPeso());
            stmt.setDouble(4, atlantico.getComprimento());  // Corrigido o �ndice para 4
            stmt.execute();
        } catch (Exception e) {
            System.out.println("Erro ao inserir produto: " + e.getMessage());
        }
    }

    
    public List<Atlantico> getAtlantico() {
        String sql = "SELECT * FROM atlantico";  // Corrigido o nome da tabela
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            
            List<Atlantico> listaAtlantico = new ArrayList<>();
            while (rs.next()) {
                Atlantico a = new Atlantico();
                a.setNome(rs.getString("nome"));
                a.setEspecie(rs.getString("especie"));
                a.setPeso(rs.getDouble("peso"));
                a.setComprimento(rs.getDouble("comprimento"));
                listaAtlantico.add(a);  
            }
            return listaAtlantico;
        } catch (Exception e) {
            e.printStackTrace();  
            return null;
        }
    }
    
        public void atualizar(Atlantico atlantico) {
    String sql = "UPDATE atlantico SET  especie=?, peso=?, comprimento=? WHERE nome=?";
    try {
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setString(1, atlantico.getNome());
        stmt.setString(2, atlantico.getEspecie());
        stmt.setDouble(3, atlantico.getPeso());
        stmt.setDouble(4, atlantico.getComprimento());

        stmt.execute();
    } catch (Exception e) {
        System.out.println("Erro ao atualizar animal: " + e.getMessage());
    }
}
    
        public void excluir(String nome) {
    String sql = "DELETE FROM atlantico WHERE nome=?";
    try {
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setString(1, nome);
        stmt.execute();
    } catch (Exception e) {
        System.out.println("Erro ao excluir animal: " + e.getMessage());
    }
}
    
}



