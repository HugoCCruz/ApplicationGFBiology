
package dao;

import Conexao.Conexao;
import beans.Atlantico;
import java.sql.Connection;
import java.sql.PreparedStatement;
import beans.Indico;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class IndicoDAO {

    List<String> listaIndico = new ArrayList<>();

    
    public void inicializarLista() {
        listaIndico = new ArrayList<>(); 
        listaIndico.add("Elemento 1");
        listaIndico.add("Elemento 2");
    }

    
    public void processarLista() {
        if (listaIndico != null) {
            for (String item : listaIndico) {
                System.out.println(item); 
            }
        } else {
            System.out.println("A lista est� vazia ou n�o foi inicializada.");
        }
    }
    
    private Conexao conexao;
    private Connection conn;

    
    public IndicoDAO() {
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }

    public void inserir(Indico indico) {
    String sql = "INSERT INTO indico (nome, especie, peso, comprimento) VALUES (?, ?, ?, ?)";
    
    try {
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setString(1, indico.getNome());
        stmt.setString(2, indico.getEspecie());
        stmt.setDouble(3, indico.getPeso());
        stmt.setDouble(4, indico.getComprimento());
        stmt.execute();
        } 
    catch (Exception e) {
        System.out.println("Erro ao inserir animal: " + e.getMessage());
        }
    }
    
    public List<Indico> getIndico() {
    String sql = "SELECT * FROM indico";
    try (PreparedStatement stmt = conn.prepareStatement(sql);
         ResultSet rs = stmt.executeQuery();) {
        List<Indico> listaIndico = new ArrayList<>();
        while (rs.next()) {
            Indico i = new Indico();
            i.setNome(rs.getString("nome"));
            i.setEspecie(rs.getString("especie"));
            i.setPeso(rs.getDouble("peso"));
            i.setComprimento(rs.getDouble("comprimento"));
            listaIndico.add(i);
        }
        return listaIndico;
    } catch (Exception e) {
        return null;
    }
}
    public void atualizar(Indico indico) {
    String sql = "UPDATE indico SET  especie=?, peso=?, comprimento=? WHERE nome=?";
    try {
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setString(1, indico.getNome());
        stmt.setString(2, indico.getEspecie());
        stmt.setDouble(3, indico.getPeso());
        stmt.setDouble(4, indico.getComprimento());

        stmt.execute();
    } catch (Exception e) {
        System.out.println("Erro ao atualizar animal: " + e.getMessage());
    }
}
    
        public void excluir(String nome) {
    String sql = "DELETE FROM indico WHERE nome=?";
    try {
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setString(1, nome);
        stmt.execute();
    } catch (Exception e) {
        System.out.println("Erro ao excluir animal: " + e.getMessage());
    }
}
}
