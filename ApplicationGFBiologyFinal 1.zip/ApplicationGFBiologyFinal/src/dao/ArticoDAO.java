package dao;

import Conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import beans.Artico;
import beans.Atlantico;
import beans.Pacifico;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ArticoDAO {
    
     List<String> listaArtico = new ArrayList<>();

    public void inicializarLista() {
        listaArtico = new ArrayList<>(); 
        listaArtico.add("Elemento 1");
        listaArtico.add("Elemento 2");
    }
     
    public void processarLista() {
        if (listaArtico != null) {
            for (String item : listaArtico) {
                System.out.println(item); 
            }
        } else {
            System.out.println("A lista est� vazia ou n�o foi inicializada.");
        }
    }
    
    private Conexao conexao;
    private Connection conn;

    public ArticoDAO() {
    this.conexao = new Conexao();
    this.conn = this.conexao.getConexao();
    }

    public void inserir(Artico artico) {
    String sql = "INSERT INTO artico (nome, especie, peso, comprimento) VALUES (?, ?, ?, ?)";
    
    try {
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setString(1, artico.getNome());
        stmt.setString(2, artico.getEspecie());
        stmt.setDouble(3, artico.getPeso());
        stmt.setDouble(4, artico.getComprimento());
        stmt.execute();
    } catch (Exception e) {
        System.out.println("Erro ao inserir animal: " + e.getMessage());
    }
    }
    
            public List<Artico> getArtico() {
    String sql = "SELECT * FROM artico";
    try (PreparedStatement stmt = conn.prepareStatement(sql);
         ResultSet rs = stmt.executeQuery();) {
        List<Artico> listaArtico = new ArrayList<>();
        while (rs.next()) {
            Artico a = new Artico();
            a.setNome(rs.getString("nome"));
            a.setEspecie(rs.getString("especie"));
            a.setPeso(rs.getDouble("peso"));
            a.setComprimento(rs.getDouble("comprimento"));
            listaArtico.add(a);
        }
        return listaArtico;
    } catch (Exception e) {
        return null;
    }
}
    public void atualizar(Artico artico) {
    String sql = "UPDATE artico SET  especie=?, peso=?, comprimento=? WHERE nome=?";
    try {
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setString(1, artico.getNome());
        stmt.setString(2, artico.getEspecie());
        stmt.setDouble(3, artico.getPeso());
        stmt.setDouble(4, artico.getComprimento());

        stmt.execute();
    } catch (Exception e) {
        System.out.println("Erro ao atualizar animal: " + e.getMessage());
    }
}
      public void excluir(String nome) {
    String sql = "DELETE FROM artico WHERE nome=?";
    try {
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setString(1, nome);
        stmt.execute();
    } catch (Exception e) {
        System.out.println("Erro ao excluir animal: " + e.getMessage());
    }
}      
            
}
