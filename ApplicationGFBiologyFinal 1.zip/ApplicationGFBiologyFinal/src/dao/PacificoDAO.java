
package dao;

import Conexao.Conexao;
import beans.Pacifico;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class PacificoDAO {
    
    List<String> listaPacifico = new ArrayList<>();

    
    public void inicializarLista() {
        listaPacifico = new ArrayList<>(); 
        listaPacifico.add("Elemento 1");
        listaPacifico.add("Elemento 2");
    }

    
    public void processarLista() {
        if (listaPacifico != null) {
            for (String item : listaPacifico) {
                System.out.println(item); 
            }
        } else {
            System.out.println("A lista est� vazia ou n�o foi inicializada.");
        }
    }
    
    private Conexao conexao;
    private Connection conn;

    public PacificoDAO() {
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }

    public void inserir(Pacifico pacifico) {
    String sql = "INSERT INTO pacifico (nome, especie, peso, comprimento) VALUES (?, ?, ?, ?)";
    
    try {
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setString(1, pacifico.getNome());
        stmt.setString(2, pacifico.getEspecie());
        stmt.setDouble(3, pacifico.getPeso());
        stmt.setDouble(4, pacifico.getComprimento());
        stmt.execute();
    } catch (Exception e) {
        System.out.println("Erro ao inserir animal: " + e.getMessage());
        }
    }
    
        public List<Pacifico> getPacifico() {
    String sql = "SELECT * FROM altantico";
    try (PreparedStatement stmt = conn.prepareStatement(sql);
         ResultSet rs = stmt.executeQuery();) {
        List<Pacifico> listaPacifico = new ArrayList<>();
        while (rs.next()) {
            Pacifico p = new Pacifico();
            p.setNome(rs.getString("nome"));
            p.setEspecie(rs.getString("especie"));
            p.setPeso(rs.getDouble("peso"));
            p.setComprimento(rs.getDouble("comprimento"));
            listaPacifico.add(p);
        }
        return listaPacifico;
    } catch (Exception e) {
        return null;
    }
}
public void atualizar(Pacifico pacifico) {
    String sql = "UPDATE pacifico SET  especie=?, peso=?, comprimento=? WHERE nome=?";
    try {
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setString(1, pacifico.getNome());
        stmt.setString(2, pacifico.getEspecie());
        stmt.setDouble(3, pacifico.getPeso());
        stmt.setDouble(4, pacifico.getComprimento());

        stmt.execute();
    } catch (Exception e) {
        System.out.println("Erro ao atualizar animal: " + e.getMessage());
    }
}
    
        public void excluir(String nome) {
    String sql = "DELETE FROM pacifico WHERE nome=?";
    try {
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setString(1, nome);
        stmt.execute();
    } catch (Exception e) {
        System.out.println("Erro ao excluir animal: " + e.getMessage());
    }
}
    
}
    
    

