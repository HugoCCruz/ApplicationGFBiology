
package applicationgfbiology;

import GUI.TelaLogin;

/**
 *
 * @author hugo.ccruz
 */
public class ApplicationGFBiology {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        TelaLogin tl = new TelaLogin();
        tl.setVisible(true);
    }
    
}
