package Conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author hugo.ccruz
 */
public class Conexao {

    public static void closeConnection(Connection conn, PreparedStatement stmt, ResultSet rs) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    public Connection getConexao() {
        try {
            Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/marinha", "root", ""
            );
            return conn;
        } catch (Exception e) {
            //System.out.println("Erro na conex�o: " + e.getMessage());
            return null;
        }
    }

    

    

    
    
}

