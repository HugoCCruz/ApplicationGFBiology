
package Conexao;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author hccru
 */
public class Conex�oAtlantico {
   
    public Connection getConexao() {
        try {
            Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/atlantico",
                    "root",
                    ""
            );
            return conn;
        } catch (Exception e) {
            //System.out.println("Erro na conex�o: " + e.getMessage());
            return null;
        }
    }
    
}
    
    

